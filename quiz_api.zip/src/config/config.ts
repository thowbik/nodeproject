
export default {
    jwtSecret: "@QEGTUI",
    dateformat: "dd/mm/yyyy"
  };