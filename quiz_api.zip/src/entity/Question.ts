import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
  RelationId
} from "typeorm";
import { Quiz } from "./Quiz";
import { QuestionOption } from "./QuestionOption";
import { QuestionAnswer } from "./QuestionAnswer";
import { QuestionSet } from "./QuestionSet";

@Entity()
// @Unique(["Name"])
export class Question {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  Id: number;

  @Column()
  Description: string;

  @Column()
  QuestionType: number;

  @Column()
  TimeAllocated: number;

  @Column()
  TimeLeft: number;

  @Column()
  SequenceNo: string;

  @Column()
  WeightageType: number;

  @Column()
  @CreateDateColumn()
  CreationTs: Date;

  @Column()
  @UpdateDateColumn()
  LastChangeTs: Date;

  @Column()
  CreationUserId: string;

  @Column()
  LastChangeUserId: string;

  @Column({ type: "boolean" })
  StatusType: boolean;

  @ManyToOne(type => Quiz, i => i.Question)
  Quiz: Quiz;
  @RelationId((self: Question) => self.Quiz)
  quizId: number


  @OneToMany(type => QuestionOption, i => i.Question, {
    cascade: false,
  })
  @JoinColumn({ name: "questionOptionId" })
  QuestionOption: QuestionOption[];


  @OneToMany(type => QuestionAnswer, quiz => quiz.Question, {
    cascade: false,
  })
  @JoinColumn({ name: "questionAnswerId" })
  QuestionAnswer: QuestionAnswer[];


  IsCompleteQuiz: boolean;

  IsAnsweredCorrectly: boolean;

  @OneToMany(type => QuestionSet, i => i.Question, {
    cascade: true,
  })
  @JoinColumn()
  QuestionSet: QuestionSet;
}