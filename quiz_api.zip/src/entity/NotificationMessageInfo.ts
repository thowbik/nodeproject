import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    JoinColumn
} from "typeorm";
import { Length, IsNotEmpty } from "class-validator";
import { Question } from "./Question";
import { text } from "express";

@Entity()
// @Unique(["Name"])
export class NotificationMessageInfo {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;

    @Column()
    Recipient: string;

    @Column({type : 'text'})
    Message: string;

    @Column({type : 'text'})
    Subject: string;

    @Column({type : 'text'})
    ExceptionMessage: string;

    @Column()
    NoOfRetries: number;

    @Column()
    NoOfAttempts: number;

    @Column()
    NotificationType: number; 

    @Column()
    MessageStatusType: number;
    

    @Column()
    @CreateDateColumn()
    CreationTs: Date;

    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({ type: "boolean" })
    StatusType: boolean;
   
}