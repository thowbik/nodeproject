import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne
  } from "typeorm";
  import { Length, IsNotEmpty } from "class-validator";
import { State } from "./State";
  
  @Entity()
  // @Unique(["Name"])
  export class Winner {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;
  
    @Column({ type: 'bigint' })
    UserId: number;
    
    @Column()
    PrizeType: number; 

    @Column()
    LevelType: number; 

    @Column()
    @CreateDateColumn()
    CreationTs: Date;
  
    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({type: "boolean"})
    StatusType: boolean;
  }