import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn
  } from "typeorm";
  
  @Entity()
  @Unique(["EmailId"])
export class EmailAccounts{
    @PrimaryGeneratedColumn()
    Id: number;
    
    @Column()
    EmailId : string

    @Column()
    EmailPassword : string
    
    @Column()
    StatusType : Boolean

    @Column()
    @CreateDateColumn()
    CreationTs: Date;
  
    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

}
