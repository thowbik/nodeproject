import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    JoinColumn
} from "typeorm";
import { Length, IsNotEmpty } from "class-validator";
import { College } from './College'
@Entity()
  // @Unique(["Name"])
  export class University {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;

    @Column()
    Name: string;
    
    
    @Column()
    @CreateDateColumn()
    CreationTs: Date;

    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column({type: "boolean"})
    StatusType: boolean;
    
    @OneToMany(type => College, college => college.University, {
        cascade: true,
    })
    @JoinColumn()
    College: College[];

  }