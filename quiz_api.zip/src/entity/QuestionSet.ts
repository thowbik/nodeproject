import { type } from "os";
import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    JoinColumn,
    RelationId
  } from "typeorm";
import { Question } from './Question';
import { QuestionOption } from "./QuestionOption";
import { User } from "./User";

  @Entity()

export class QuestionSet {
  @PrimaryGeneratedColumn({ type: 'bigint' })
  Id: number;

  @Column()
  StatusType : Boolean;

/*   @Column()
  questionDescription : string; */

  @Column()
   questionSetId: number;
 

  
  @ManyToOne(type => Question, i => i.QuestionSet)
  Question: Question;   

/*   @ManyToOne(type => Question, i => i.QuestionOption)
    QuestionOption: Question;  */
  /* @RelationId((self: QuestionOption) => self.Question)
  questionId: number */

  @OneToMany(type => QuestionOption, i => i.Question, {
    cascade: true,
  })
  @JoinColumn({ name: "questionOptionId" })
  questionOptionId: QuestionOption[];
  
 /*  @OneToMany(type => User, i => i.QuestionSetId, {
    cascade: true,
  })
  @JoinColumn()
  QuestionSetID: User; */
}