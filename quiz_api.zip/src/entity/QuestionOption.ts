import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    JoinColumn,
    RelationId
  } from "typeorm";
  import { Length, IsNotEmpty } from "class-validator";
import { Question } from "./Question";
import { QuestionAnswer } from "./QuestionAnswer";
  
  @Entity()
  // @Unique(["Name"])
  export class QuestionOption {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;
  
    @Column()
    Description: string;

    @Column({type: "boolean"})
    IsCorrectAnswer: boolean;   
   
    @Column()
    @CreateDateColumn()
    CreationTs: Date;
  
    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({type: "boolean"})
    StatusType: boolean;

    
    @Column()
    SequenceNo: string;

    @ManyToOne(type => Question, i => i.QuestionOption)
    Question: Question; 
    @RelationId((self: QuestionOption) => self.Question)
    questionId: number

    @OneToMany(type => QuestionAnswer, i => i.QuestionOption, {
      cascade: false,
    })
    @JoinColumn({ name: "questionAnswerId" })
    QuestionAnswer: QuestionAnswer[];

    isSelectedOption: boolean;
  }