import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    OneToMany,
    JoinColumn
  } from "typeorm";
  import { Length, IsNotEmpty } from "class-validator";
  import { State } from "./State";
  import { College } from "./College";
  
  @Entity()
  // @Unique(["Name"])
  export class District {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;
  
    @Column()
    @Length(0, 50)
    Name: string;

    @Column()
    @Length(0, 50)
    TamilName: string;   
   
    @Column()
    @CreateDateColumn()
    CreationTs: Date;
  
    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({type: "boolean"})
    StatusType: boolean;

    @ManyToOne(type => State, i => i.District)
    State: State;  

    @OneToMany(type => College, college => college.District, {
      cascade: true,
    })
    @JoinColumn()
    College: College[];

  }