import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    JoinColumn,
    ManyToOne
  } from "typeorm";
import { User } from "./User";

@Entity()

  export class UserSelectedAnswers {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;

    @Column()
    AnswerString : string;

    @Column({ type: 'bigint' })
    DurationTakenInSeconds : number;

    @Column()
    quizId : number;

    @ManyToOne(type => User, i => i.Id)
    User: User; 
  }