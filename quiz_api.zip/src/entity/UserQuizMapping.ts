import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    JoinColumn
} from "typeorm";
import { Length, IsNotEmpty } from "class-validator";
import { Question } from "./Question";

@Entity()
// @Unique(["Name"])
export class UserQuizMapping {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;

    @Column({ type: 'bigint' })
    quizId: number;

    @Column({ type: 'bigint' })
    userId: number;

    @Column()
    questionIdList: string;

    @Column()
    @CreateDateColumn()
    CreationTs: Date;

    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({ type: "boolean" })
    StatusType: boolean;
    
}