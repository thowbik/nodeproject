import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    ManyToOne,
    RelationId
  } from "typeorm";
  import { Length, IsNotEmpty } from "class-validator";
import { Question } from "./Question";
import { QuestionOption } from "./QuestionOption";
import { User } from "./User";
  
  @Entity()
  // @Unique(["Name"])
  export class QuestionAnswer {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;
  
    @Column()
    TimeTaken: number;
   
    @Column()
    @CreateDateColumn()
    CreationTs: Date;
  
    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column({ type: 'bigint' })
    quizId: number;

    @Column()
    LastChangeUserId: string;

    @Column({type: "boolean"})
    StatusType: boolean;

    @Column({type: "boolean"})
    IsCompleteQuiz: boolean;    

    @ManyToOne(type => Question, i => i.QuestionAnswer)
    Question: Question;
    @RelationId((self: QuestionAnswer) => self.Question)
    questionId: number
    
    @ManyToOne(type => QuestionOption, i => i.QuestionAnswer)
    QuestionOption: QuestionOption;
    @RelationId((self: QuestionAnswer) => self.QuestionOption)
    questionOptionId: number

    @ManyToOne(type => User, i => i.QuestionAnswer)
    User: User;
    @RelationId((self: QuestionAnswer) => self.User)
    userId: number

    
  }