import {
    Entity,
    PrimaryGeneratedColumn,
    Column,
    Unique,
    CreateDateColumn,
    UpdateDateColumn,
    OneToMany,
    JoinColumn
} from "typeorm";
import { Length, IsNotEmpty } from "class-validator";
import { Question } from "./Question";

@Entity()
// @Unique(["Name"])
export class Quiz {
    @PrimaryGeneratedColumn({ type: 'bigint' })
    Id: number;

    @Column()
    Title: string;

    @Column()
    StartDate: Date;

    @Column()
    EndDate: Date;

    @Column()
    @CreateDateColumn()
    CreationTs: Date;

    @Column()
    @UpdateDateColumn()
    LastChangeTs: Date;

    @Column()
    CreationUserId: string;

    @Column()
    LastChangeUserId: string;

    @Column({ type: "boolean" })
    StatusType: boolean;
    @OneToMany(type => Question, question => question.Quiz, {
        cascade: true,
    })
    @JoinColumn( { name: "questionId" })
    Question: Question[];

    isExpired: boolean;

    totalQuestion: number;

    totalTime: string;

    isAnswered: boolean;

    isOpened: boolean;
}